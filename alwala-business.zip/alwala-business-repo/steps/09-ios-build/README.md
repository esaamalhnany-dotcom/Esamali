# 📌 الخطوة 9 — بناء تطبيق آيفون

## 🎯 الهدف
إنتاج نسخة iOS للنشر على App Store

## ✅ المهام
- [ ] حساب Apple Developer
- [ ] flutter build ios --release
- [ ] اختبار على iPhone

## 📂 الملفات المرتبطة
- الكود: `app/lib/features/` (حسب الخطوة)
- النموذج التجريبي: `web-prototype/index.html`

## 🔄 كيف أعدّل هذه الخطوة؟
1. عدّل هذا الملف لتوثيق التغيير
2. عدّل الكود المرتبط فقط
3. حدّث `CHANGELOG.md`
4. ارفع على GitHub: `git add . && git commit -m "feat: الخطوة 9 — بناء تطبيق آيفون" && git push`

## 🗑️ كيف أحذف هذه الخطوة؟
1. احذف هذا المجلد بالكامل
2. احذف كودها من `app/lib/features/`
3. سجّل الحذف في `CHANGELOG.md`
4. ارفع على GitHub
