# 📌 الخطوة 1 — تجهيز المشروع والهيكل

## 🎯 الهدف
إنشاء هيكل الملفات والمجلدات وملفات GitHub الأساسية

## ✅ المهام
- [x] إنشاء README.md
- [x] إنشاء .gitignore
- [x] إنشاء LICENSE و CHANGELOG
- [x] إنشاء مجلدات steps و docs و app
- [x] إنشاء النموذج التجريبي web-prototype
- [ ] رفع المشروع على GitHub (انظر docs/03-GitHub-Guide.md)

## 📂 الملفات المرتبطة
- الكود: `app/lib/features/` (حسب الخطوة)
- النموذج التجريبي: `web-prototype/index.html`

## 🔄 كيف أعدّل هذه الخطوة؟
1. عدّل هذا الملف لتوثيق التغيير
2. عدّل الكود المرتبط فقط
3. حدّث `CHANGELOG.md`
4. ارفع على GitHub: `git add . && git commit -m "feat: الخطوة 1 — تجهيز المشروع والهيكل" && git push`

## 🗑️ كيف أحذف هذه الخطوة؟
1. احذف هذا المجلد بالكامل
2. احذف كودها من `app/lib/features/`
3. سجّل الحذف في `CHANGELOG.md`
4. ارفع على GitHub
