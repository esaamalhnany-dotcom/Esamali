# 🐙 دليل الرفع على GitHub

## العنوان: كيف ترفع المشروع على GitHub خطوة بخطوة

### 1) إنشاء المستودع على GitHub
1. ادخل إلى github.com وسجّل الدخول
2. اضغط **New repository**
3. الاسم: `alwala-business`
4. اختر **Public** أو **Private**
5. لا تفعّل README (لدينا ملف جاهز)
6. اضغط **Create repository**

### 2) ربط المشروع المحلي بـ GitHub
```bash
cd alwala-business
git init
git add .
git commit -m "feat: الخطوة 1 - تجهيز مشروع الولاء بزنز"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/alwala-business.git
git push -u origin main
```
> استبدل `YOUR-USERNAME` باسم حسابك على GitHub.

### 3) التحديث بعد أي تعديل
```bash
git add .
git commit -m "feat: الخطوة 3 - تحديث إدارة الفروع"
git push
```

### 4) إضافة بند جديد مستقبلاً
1. أنشئ مجلد `steps/11-.../README.md`
2. أضف الكود في `app/lib/features/`
3. حدّث `CHANGELOG.md`
4. `git add . && git commit && git push`

### 5) حذف بند
1. احذف مجلده وكوده
2. سجّل في `CHANGELOG.md`
3. `git add . && git commit && git push`
