// ============================================================
// الخطوة 3 — نموذج بيانات الفرع (Branch Model)
// ============================================================
class Branch {
  final String id;
  final String name;
  final String city;
  final String manager;
  final String phone;
  final String status; // active | soon | closed
  final int performance; // 0-100

  Branch({
    required this.id,
    required this.name,
    required this.city,
    required this.manager,
    required this.phone,
    required this.status,
    required this.performance,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'name': name, 'city': city, 'manager': manager,
        'phone': phone, 'status': status, 'performance': performance,
      };

  factory Branch.fromMap(Map<String, dynamic> m) => Branch(
        id: m['id'] ?? '',
        name: m['name'] ?? '',
        city: m['city'] ?? '',
        manager: m['manager'] ?? '',
        phone: m['phone'] ?? '',
        status: m['status'] ?? 'active',
        performance: m['performance'] ?? 0,
      );
}
