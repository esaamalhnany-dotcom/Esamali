// ============================================================
// الخطوة 4 — نموذج بيانات القسم (Section Model)
// كل قسم ينتمي إلى فرع عبر branchId
// ============================================================
class Section {
  final String id;
  final String branchId;
  final String name;
  final String description;
  final int employees;

  Section({
    required this.id,
    required this.branchId,
    required this.name,
    required this.description,
    required this.employees,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'branchId': branchId, 'name': name,
        'description': description, 'employees': employees,
      };

  factory Section.fromMap(Map<String, dynamic> m) => Section(
        id: m['id'] ?? '',
        branchId: m['branchId'] ?? '',
        name: m['name'] ?? '',
        description: m['description'] ?? '',
        employees: m['employees'] ?? 0,
      );
}
