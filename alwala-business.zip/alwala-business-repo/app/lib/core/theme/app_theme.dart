// ============================================================
// الخطوة 1 — ملف الألوان والهوية البصرية
// لتغيير ألوان التطبيق كلها، عدّل هذا الملف فقط
// ============================================================
import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF0B1F35);
  static const navy2 = Color(0xFF122E4D);
  static const gold = Color(0xFFC9A86A);
  static const teal = Color(0xFF0EA5A0);
  static const bg = Color(0xFFF4F6F9);
}

class AppTheme {
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.navy,
          primary: AppColors.navy,
          secondary: AppColors.gold,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.navy,
          foregroundColor: Colors.white,
        ),
        fontFamily: 'Tahoma',
      );
}
