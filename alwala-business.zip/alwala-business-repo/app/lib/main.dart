// ============================================================
// الولاء بزنز — Alwala Business
// الخطوة 1: نقطة بداية التطبيق
// يعمل على جميع الهواتف: Android + iOS
// ============================================================
import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/dashboard/dashboard_screen.dart';

void main() {
  runApp(const AlwalaApp());
}

class AlwalaApp extends StatelessWidget {
  const AlwalaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الولاء بزنز',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const DashboardScreen(),
    );
  }
}
